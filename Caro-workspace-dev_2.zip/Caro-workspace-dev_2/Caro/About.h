#pragma once
#include "D2_data.h"

int About();
void HandleKeyForAbout(int X, int Y, KEY_EVENT_RECORD key);