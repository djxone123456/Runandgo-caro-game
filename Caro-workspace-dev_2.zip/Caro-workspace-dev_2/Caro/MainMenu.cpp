#include "MainMenu.h"

char* MainMenu()
{
	return nullptr;
}
