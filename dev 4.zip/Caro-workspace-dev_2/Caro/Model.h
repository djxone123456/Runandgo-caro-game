#pragma once
#ifndef MODEL_H
#define MODEL_H

#include "data.h"

void ResetData();

#endif