#pragma once

#include "Data.h"
#include "Control.h"
#include "View.h"
#include "Error.h"

//Name file position
extern int Name_X;
extern int Name_Y;

//File Info possition
extern int Info_X;
extern int Info_Y;

extern int Locate;
//ten file can load
extern string Name[];

// So file da luu
extern int Numb_of_file;