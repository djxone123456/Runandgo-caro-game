#include "LoadData.h"

// Toa do ten file
int Name_X = 52;
int Name_Y = 14;

//toa do thong tin file
int Info_X = 72;
int Info_Y = 14;

string Name[15];

int Numb_of_file;

int Locate = 1;


